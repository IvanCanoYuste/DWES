
    <?php

        echo "Hola " .$_GET["modulo"]." ". $_GET["ciclo"];
    ?>
