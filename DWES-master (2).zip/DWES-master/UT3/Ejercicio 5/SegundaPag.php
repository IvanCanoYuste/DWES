<?php
    if($_POST['color'] == "blanco"){
        echo "Enhorabuena";
    }else{
        echo "Intentalo de nuevo";
    }