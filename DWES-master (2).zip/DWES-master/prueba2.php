<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>

<body>
    <h1>Hola mundo</h1>

    <?php
    echo "<h2>Hola  buenas</h2>";
    ?>
</body>

</html>