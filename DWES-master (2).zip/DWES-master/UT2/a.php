<?php
    class a{
        function sayHello(){
            echo "Hello";
        }
        
    }
?>