<?PHP 
    $num = 4;
    $num4  = 8.6;
    echo "Hola mundo";

    echo var_dump($num);

    echo var_dump($num4);


    
?>